Gingham is an experimental variable font by Christoph Koeberlin with two axes and a very limited character set. It is based on an unfinished design and comes without warranty. Have fun playing around with it in the latest Webkit Nightly.

Download
http://koe.berlin/variablefont/

License 
Attribution-NonCommercial-NoDerivatives 4.0 International (CC BY-NC-ND): https://creativecommons.org/licenses/by-nc-nd/4.0/

Copyright © 2016 http://christoph.koe.berlin 